/* Generated automatically. */
static const char configuration_arguments[] = "./configure --target=mips-elf --enable-languages=c,c++ --prefix=/usr/local --mandir=/usr/local/man --infodir=/usr/local/info --disable-nls --disable-shared --disable-werror --with-gnu-as --with-gnu-ld";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
