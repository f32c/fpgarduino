#!/bin/sh
scp bm/fpgarduino.zip  login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/bootloaders.zip login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/ujprog-i686-pc-linux-gnu.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/ujprog-x86_64-pc-linux-gnu.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/ujprog-x86_64-apple-darwin.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/ujprog-win32.zip login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/openocd-0.9.0-linux32.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/openocd-0.9.0-linux64.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/openocd-0.9.0-windows.zip login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/xc3sprog-771-win32.zip login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/xc3sprog-774-linux32.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
#scp bm/xc3sprog-774-linux64.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
scp bm/numato-1.0.0-python3.zip login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
scp bm/fleafpga-jtag-12.2-linux32.tar.bz2 login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/bm/
scp package_f32c_core_index.json login.nxlab.fer.hr:/jails/www/usr/local/www/data/fpgarduino/
