/*
Author=EMARD
License=CC
*/
#include "PCM.h"

/* constructor does nothing */
PCM::PCM()
{
}
