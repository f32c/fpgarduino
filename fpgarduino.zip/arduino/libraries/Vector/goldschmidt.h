#ifndef GOLDSCHMIDT_H
#define GOLDSCHMIDT_H
#include "vector_link.h"
void divide_goldschmidt(union ifloat_u *result, union ifloat_u *x, union ifloat_u *y);
#endif

