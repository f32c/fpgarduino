#ifndef FPROG_H
#define FPROG_H

void fprog(void);
#endif
