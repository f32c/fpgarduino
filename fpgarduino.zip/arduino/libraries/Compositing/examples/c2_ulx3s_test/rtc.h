void rtc_init();
void rtc_read(char *a);
void rtc_set_alarm();
void rtc_set_clock();
void rtc_clear_interrupts();

