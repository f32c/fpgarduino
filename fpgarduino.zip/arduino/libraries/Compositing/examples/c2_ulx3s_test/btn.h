void btn_init();
void btn_read(char *line);

