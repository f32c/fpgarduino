void adc_init();
void adc_read(char *a);

