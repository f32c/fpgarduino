void flash_read(char *a);
