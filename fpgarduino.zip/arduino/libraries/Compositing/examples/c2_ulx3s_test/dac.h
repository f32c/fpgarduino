void dac_init();
void dac_read(char *a);

