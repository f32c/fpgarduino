uint8_t spi_start_tx(volatile uint16_t *port);
uint8_t spi_rxtx(volatile uint16_t *port, uint8_t _data);
