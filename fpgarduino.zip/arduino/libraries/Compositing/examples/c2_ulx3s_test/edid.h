int edidreadbytes(char *array);
byte edidchecksum(char *array);
void edid_read(char *a);

