void rds_init();
