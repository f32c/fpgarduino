void pcm_tone();
void pcm_mute();
void pcm_init();
