void sd_read(char *a);
