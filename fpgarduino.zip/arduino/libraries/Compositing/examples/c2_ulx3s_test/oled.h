void oled_init();
void oled_read(char *a);
