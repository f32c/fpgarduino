void ram_test(char *a);

