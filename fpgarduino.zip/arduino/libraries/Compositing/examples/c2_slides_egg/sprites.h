void setup_sprites();
void prepare_sprites();
void loop_sprites();
void stop_sprites();
