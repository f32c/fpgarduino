/* Generated automatically. */
static const char configuration_arguments[] = "./configure --target=riscv32-elf --enable-languages=c,c++ --prefix=/tmp/f32c --mandir=/tmp/f32c/man --infodir=/tmp/f32c/info --disable-nls --disable-shared --disable-werror --with-gnu-as --with-gnu-ld";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "ilp32d" }, { "arch", "rv32gc" } };
